<?php
require '../functions/Controller.php';
$Controller = new Controller;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="" />
  <meta name="keywords" content="" />
  <link rel="icon" href="../assets/favicon.png">
  <title>FoxFundraiser: Admin Dashboard</title>
  <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
  <!-- Option 1: Include in HTML -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
  <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="main-wrapper">
  <div class="row" style="padding:0 1em;">
    <div class="col-sm-3 p-0">
      <div class="sidebar py-3">
        <h4 class="text-white mb-5 px-3 py-2"><b>FoxFundraiser</b></h4>
        <!-- <h6 class="menu-heading text-light mb-4"><span>menu</span></h6> -->

        <div class="sidelinks">
          <a href="#home" class="hashlinks"><span>Home</span></a>
          <a href="#causes" class="hashlinks"><span>Donations</span></a>
          <a href="#payment" class="hashlinks"><span>Payment Details</span></a>
          <a href="#contact" class="hashlinks"><span>Contact Details</span></a>
          <a href="#settings" class="hashlinks"><span>Settings</span></a>
          <a href="#" class="hashlinks"><span>Logout</span></a>
        </div>
      </div>
    </div>

    <div class="col-sm-9 px-0">
      <div class="main-content container text-light">
        <div class="main-content-header w-100 py-3 sticky-top" style="background-color:seagreen;">
          <div class="user-icon d-flex ml-auto bg-dark">
            <i class="bi bi-person-fill m-auto" style="color:seagreen;font-size:1.6em;"></i>
          </div>
        </div>

        <div class="page-body" id="home">
          <h1>Home</h1>
          <hr class="border-light mb-4" />
        </div>
        <div class="page-body" id="causes">
          <h1>Donations</h1>
          <hr class="border-light mb-4" />

          <div class="donation-wrapper row">
            <div class="col-sm-4 mb-3">
              <button class="btn donation-item h-100 w-100 text-light"
                data-toggle="modal"
                data-target="#newDonation">
                <span class="h5">Add new</span>
              </button>
            </div>
            <?php
              foreach ($Controller->causes() as $key => $value) {
                $percent = ($value['amount_raised'] / $value['amount']) * 100;
                $percent = round($percent);
                ?>
                <div class="col-sm-4 mb-3">
                  <div class="donation-item h-100 w-100">
                    <div class="w-100 img mb-3"
                      style="background-image:url('../assets/images/resources/<?php echo $value['banner']; ?>');">
                    </div>
                    <div class="info p-2">
                      <div class="load mb-2">
                        <div class="load-bar" style="width:<?php echo $percent.'%'; ?>;"><span><?php echo $percent.'%'; ?></span></div>
                      </div>
                      <p class="mb-1 d-flex w-100">
                        <small class="cus-amt"><i class="thm-clr">$<?php echo number_format($value['amount_raised']); ?> Raised</i> of $<?php echo number_format($value['amount']); ?></small>
                        <small class="ml-auto"><?php echo $value['donors']; ?> Donors</small>
                      </p>
                      <p class="mb-0">Posted: <?php echo date('d M, Y', strtotime($value['cause_date'])); ?></p>
                    </div>
                  </div>
                </div>
                <?php
              }
            ?>
          </div>
        </div>
        <div class="page-body" id="payment">
          <h1>Payments</h1>
          <hr class="border-light mb-4" />
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Add Modal -->
<div class="modal fade" id="newDonation" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog pb-5">
    <form class="modal-content" id="donationForm" enctype="multipart/formdata" method="POST">
      <div class="modal-header">
        <h5 class="modal-title">Add new Donation</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">&times;</button>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label>Title *</label>
          <input type="text" name="title" required class="form-control">
        </div>
        <div class="form-group">
          <label>Amount *</label>
          <input type="number" name="amount" required class="form-control">
        </div>
        <div class="form-group">
          <label>Amount raised *</label>
          <input type="number" name="amount_raised" required class="form-control">
        </div>
        <div class="form-group">
          <label>Donors *</label>
          <input type="number" name="donors" required class="form-control">
        </div>
        <div class="form-group">
          <label>Image *</label>
          <input type="file" name="banner" required class="form-control">
        </div>
        <div class="form-group">
          <label>Details *</label>
          <textarea name="details" required class="form-control"></textarea>
        </div>
        <div class="form-group">
          <label>Event date</label>
          <input type="date" name="cause_date" class="form-control">
        </div>
        <div class="feedback"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="hidden" name="add_donation" />
        <button type="submit" class="btn btn-primary submit-btn">Submit</button>
      </div>
    </form>
  </div>
</div>

<script src="../assets/js/jquery.min.js"></script>
<script src="../assets/js/bootstrap.min.js"></script>
<script>
$(document).ready(function() {
  // Function to handle hash change event
  function handleHashChange() {
    var hash = window.location.hash;
    var target = $('.page-body'+hash);

    $(".hashlinks").removeClass('active');
    $('a[href="' + hash + '"]').addClass('active');
    
    
    // Show the target section
    if (window.location.hash) {
      $('.page-body').removeClass('active');
      target.addClass('active');
    }else {
      $('.page-body').removeClass('active');
      // If target not found, show default section or do nothing
      $('.page-body#home').addClass('active');
      $('a[href="#home"]').addClass('active');
    }
  }
  
  // Trigger hash change event on page load
  handleHashChange();
  
  // Listen for hash change event
  $(window).on('hashchange', handleHashChange);

  $("#donationForm").on('submit', function(e){
    e.preventDefault();

    $.ajax({
      url: "process.php",
      type: "POST",
      data: new FormData(this),
      cache: false,
      contentType: false,
      processData: false,
      beforeSend: function() {
        $("#donationForm .submit-btn").html("loading... <i class='fa fa-cog fa-spin'></i>");
      },
      success: function(data) {
        $("#donationForm .submit-btn").html("Submit");
        $("#donationForm .feedback").html(data);
        
        if ( data.search('success') !== -1 ) {
          // $("#donationForm input").val("");
           window.location.reload();
          // window.location.href = "dashboard";
        }

      },
      error: function() {
        $("#donationForm .submit-btn").html("Submit");
        $("#donationForm .feedback").html("<div class='alert alert-danger'><i class='bi bi-exclamation-triangle'></i> Sorry, and error occured! <br /> Try again later.</div>");
      }
    });
  });
});
</script>
</body>
</html>